﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mileage
{
   class Trip
   {
      public string name;
      public List<Location> locations = new List<Location>();
      public string distance;
      public string description;

      public Trip(string name, IEnumerable<Location> list, string distance, string description)
      {
         this.name = name;
         this.distance = distance;
         this.description = description;
         locations = list.ToList();
      }
   }
}
