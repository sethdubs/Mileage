﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mileage
{
   class Location
   {
      public string name;
      public string address;
      public string locationCode;

      public Location(string name, string address, string locationCode)
      {
         this.name = name;
         this.address = address;
         this.locationCode = locationCode;
      }
   }
}
