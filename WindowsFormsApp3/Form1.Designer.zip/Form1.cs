﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * [STAThread]
 * public static void Main()
 * {
 *     var settings = new CefSettings();
 *     settings.BrowserSubprocessPath = @"x86\CefSharp.BrowserSubprocess.exe";
 * 
 *     Cef.Initialize(settings, performDependencyCheck: false, browserProcessHandler: null);
 * 
 *     var browser = new BrowserForm();
 *     Application.Run(browser);
 * }
 */

namespace Mileage
{
   public partial class Form1 : Form
   {
      public Form1()
      {
         InitializeComponent();
      }

      private void buttonAddNew_Click(object sender, EventArgs e)
      {
         //Form frmloc = new frmLocation();
         //frmloc.ShowDialog();

         Form frmTrip = new frmTrip();
         frmTrip.ShowDialog();

      }
   }
}
